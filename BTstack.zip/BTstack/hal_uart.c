/**
 * @file  hal_bt.c
 ***************************************************************************/
#include <stm32f10x.h>
#include <stdint.h>
#include <btstack/hal_uart_dma.h>
#include <stm32f10x_usart.h>
#include <stm32f10x_gpio.h>
#include <stm32f10x_exti.h>
#include "FreeRTOS.h"
#include "task.h"
#include "bsp_btuart.h"

void dummy_handler(void){};

// handlers
//static void (*rx_done_handler)(void) = dummy_handler;
//static void (*tx_done_handler)(void) = dummy_handler;
static void (*cts_irq_handler)(void) = dummy_handler;


void hal_uart_dma_init(void)
{
	BSP_BTUART_Initialise();
}

int hal_uart_dma_set_baud(uint32_t baud)
{
	BSP_BTUART_SetBaudrate(baud);
	return 0;
}

void hal_uart_dma_set_block_received( void (*the_block_handler)(void))
{
	while(1);
    //BSP_BTUART_EnableRxCallback(the_block_handler);
}

void hal_uart_dma_set_block_sent( void (*the_block_handler)(void))
{
	while(1);
    //tx_done_handler = the_block_handler;
}

void hal_uart_dma_set_csr_irq_handler( void (*the_irq_handler)(void)){
    if (the_irq_handler){
        NVIC_EnableIRQ(EXTI15_10_IRQn);
        cts_irq_handler = the_irq_handler;
        return;
    }

    NVIC_DisableIRQ(EXTI15_10_IRQn);
    cts_irq_handler = dummy_handler;
}

void hal_uart_dma_shutdown(void) {
	// nothing
	//BSP_BTUART_DisableRxCallback();
}

inline void hal_uart_dma_send_block(const uint8_t * data, uint16_t len)
{
	BSP_BTUART_Transmit(data, len);
}

static inline void hal_uart_dma_enable_rx(void){
    GPIO_ResetBits(GPIOA, GPIO_Pin_12);  // = 0 - RTS low -> ok
}

static inline void hal_uart_dma_disable_rx(void){
	GPIO_SetBits(GPIOA, GPIO_Pin_12);  // = 1 - RTS high -> stop
}

// int used to indicate a request for more new data
void hal_uart_dma_receive_block(uint8_t *buffer, uint16_t len)
{
	unsigned long temp;
	BSP_BTUART_Receive(buffer, len, &temp, portMAX_DELAY);
    hal_uart_dma_enable_rx();     // enable receive
}

void hal_uart_dma_set_sleep(uint8_t sleep){
    //hal_cpu_set_uart_needed_during_sleep(!sleep);
	// do nothing
}

// CTS ISR
extern void ehcill_handle(uint8_t action);
#define EHCILL_CTS_SIGNAL      0x034

void EXTI15_10_IRQHandler(void)
{
  if(EXTI_GetITStatus(EXTI_Line11) != RESET)
  {
	(*cts_irq_handler)();

    // Clear the  EXTI line 11 pending bit
    EXTI_ClearITPendingBit(EXTI_Line11);
  }
}

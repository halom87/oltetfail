/*=============================================================================
* (C) Copyright Albis Technologies Ltd 2011
*==============================================================================
*                STM32 Example Code
*==============================================================================
* File name:     bsp_btuart_nodma.c
*
* Notes:         STM32 Bluetooth UART driver without DMA.
*============================================================================*/

#include "bsp_btuart.h"
#include <FreeRTOS.h>
#include <FreeRTOSConfig.h>
#include <queue.h>
#include <task.h>
#include "stm32f10x_gpio.h"
#include "stm32f10x_usart.h"

/* BT UART is USART1  */
#define BTUART_INST_IN_USE  USART1
#define BTUART_RESET_PORT 	GPIOA
#define BTUART_RESET_PIN	GPIO_Pin_4

/* USART instance in use. */
static USART_TypeDef *usartInst = 0;

/* UART */
#define RX_QUEUE_BUFFER_SIZE 512
#define TX_QUEUE_BUFFER_SIZE 512
static xQueueHandle rxQueue;
static xQueueHandle txQueue;

/* UART receiver with callback. */
static RxCallbackFunc rxCallbackFunc = 0;

//=============================================================================
//=============================================================================
void USART1_IRQHandler (void)
{
    uint8_t rxData = 0;
    uint8_t txData = 0;
    portBASE_TYPE err = 0;
    portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

    if(USART_GetITStatus(usartInst, USART_IT_RXNE) != RESET)
    {
        rxData = USART_ReceiveData(usartInst) & 0xff;

        /*
        if(rxCallbackFunc)
        {
            rxCallbackFunc((unsigned char *)&rxData, 1);
        }
        else
        {
        */
            err = xQueueSendFromISR(rxQueue, &rxData, &xHigherPriorityTaskWoken );
            if(err == pdTRUE)
            {
                // Ok.
            }
            else
            {
                while (1);
            }
        //}

        USART_ClearITPendingBit(usartInst, USART_IT_RXNE);
    }
    else if(USART_GetITStatus(usartInst, USART_IT_TXE) != RESET)
    {
    	if (xQueueReceiveFromISR(txQueue, &txData, &xHigherPriorityTaskWoken) == pdTRUE)
    	{
    		USART_SendData(usartInst, txData & 0xff);
    	}
    	else
    	{
    		USART_ITConfig(usartInst, USART_IT_TXE, DISABLE);
    	}
    	USART_ClearITPendingBit(usartInst, USART_IT_TXE);
    }

    portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}

/*=============================================================================
=============================================================================*/
/*
 * NVIC, GPIO, RCC are already configured
 * only needs to configure USART
 * Dont forget to init the BT RESET pin too!
 */
void BSP_BTUART_Initialise(void)
{
	USART_ClockInitTypeDef usartClkInit;
	portTickType xLastWakeTime;

    /* UART instance in use. */
    usartInst = BTUART_INST_IN_USE;

    /* Create Rx queue. */
    rxQueue = xQueueCreate(RX_QUEUE_BUFFER_SIZE, sizeof(uint8_t) );
    txQueue = xQueueCreate(TX_QUEUE_BUFFER_SIZE, sizeof(uint8_t) );

    // Two edge clock: in BSP_BTUART_SetBaudrate the baudrate has to be divided by 2 !!!
    USART_ClockStructInit(&usartClkInit);
    usartClkInit.USART_Clock = USART_Clock_Disable;
    usartClkInit.USART_CPOL = USART_CPOL_Low;
    usartClkInit.USART_CPHA = USART_CPHA_2Edge;
    usartClkInit.USART_LastBit = USART_LastBit_Disable;

    BSP_BTUART_SetBaudrate(115200);
    USART_ClockInit(usartInst, &usartClkInit);
    USART_Cmd(usartInst, ENABLE);

	xLastWakeTime=xTaskGetTickCount();
    BSP_BTUART_ActivateReset();
    vTaskDelayUntil(&xLastWakeTime,100 * portTICKS_PER_MS);
    BSP_BTUART_DeactivateReset();
    vTaskDelayUntil(&xLastWakeTime,2000 * portTICKS_PER_MS);

    USART_ITConfig(usartInst, USART_IT_RXNE, ENABLE);
    USART_ITConfig(usartInst, USART_IT_TXE, ENABLE);
}

/*=============================================================================
=============================================================================*/
void BSP_BTUART_SetBaudrate(unsigned long baudrate)
{
    USART_InitTypeDef usartInit;

    USART_StructInit(&usartInit);
    // Two edge clock: in BSP_BTUART_SetBaudrate the baudrate has to be divided by 2 !!!
    usartInit.USART_BaudRate = baudrate / 2;
    usartInit.USART_WordLength = USART_WordLength_8b;
    usartInit.USART_StopBits = USART_StopBits_1;
    usartInit.USART_Parity = USART_Parity_No;
    usartInit.USART_HardwareFlowControl = USART_HardwareFlowControl_RTS_CTS;
    usartInit.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

    USART_Init(usartInst, &usartInit);
}

/*=============================================================================
=============================================================================*/
void BSP_BTUART_ActivateReset(void)
{
    GPIO_ResetBits(BTUART_RESET_PORT, BTUART_RESET_PIN);
}

/*=============================================================================
=============================================================================*/
void BSP_BTUART_DeactivateReset(void)
{
    GPIO_SetBits(BTUART_RESET_PORT, BTUART_RESET_PIN);
}

/*=============================================================================
=============================================================================*/
void BSP_BTUART_Transmit(const unsigned char *buffer, unsigned long count)
{
    unsigned int i = 0;

    for(i = 0; i < count; ++i)
    {
    	/*
        while(USART_GetFlagStatus(usartInst, USART_FLAG_TXE) != SET);
        USART_SendData(usartInst, buffer[i]);
        */
    	xQueueSend( txQueue, &buffer[i], portMAX_DELAY);
    }
    if (i != 0)
    {
    	USART_ITConfig(usartInst, USART_IT_TXE, ENABLE);
    }
}

/*=============================================================================
=============================================================================*/
void BSP_BTUART_AnounceDmaReceiverSize(unsigned long count)
{
    /* Nothing to do: no DMA. */
}

/*=============================================================================
=============================================================================*/
void BSP_BTUART_Receive(unsigned char *buffer,
                        unsigned long maxCount,
                        unsigned long *rxCount,
                        unsigned long timeout)
{
    portBASE_TYPE err;
    uint8_t event = 0;
    unsigned long rxCounter = 0;
    unsigned short timeoutTicks = portTICKS_PER_MS * timeout;

    for(;;)
    {
    	err = xQueueReceive(rxQueue, &event, timeoutTicks);

        if(err == pdTRUE)
        {
            buffer[rxCounter++] = (unsigned char)event;

            if(rxCounter >= maxCount)
            {
                // Received expected number of bytes.
                break;
            }
        }
        else
        {
        	// Should never get here!
            while(1);
        }
    }

    if(rxCount)
    {
        *rxCount = rxCounter;
    }
}

/*=============================================================================
=============================================================================*/
void BSP_BTUART_DrainReceiver(void)
{
    portBASE_TYPE err;
    uint8_t temp;
    do
    {
    	err = xQueueReceive(rxQueue, &temp, 1);
    } while(err == pdTRUE);
}

/*=============================================================================
=============================================================================*/
void BSP_BTUART_EnableRxCallback(RxCallbackFunc callbackFunc)
{
    rxCallbackFunc = callbackFunc;
}

/*=============================================================================
=============================================================================*/
void BSP_BTUART_DisableRxCallback(void)
{
    rxCallbackFunc = 0;
}
